
args_parsing = False

def enable_args_parsing(enable=True):
    global args_parsing
    args_parsing = enable
